__device__ __forceinline__ void MFGivens(Scalar* Rp, Scalar* v){
  const int ix[3][3]={{0,1,2},{-1,3,4},{-1,-1,5}};
  for(int j=0;j<3;++j){
    Scalar vj=v[j]; if(vj==0.0) continue;
    Scalar rjj=Rp[ix[j][j]];
    Scalar rr=hypot(rjj,vj); if(rr==0.0) continue;
    Scalar cs=rjj/rr, sn=vj/rr; Rp[ix[j][j]]=rr;
    for(int k=j+1;k<3;++k){ Scalar t1=Rp[ix[j][k]],t2=v[k];
      Rp[ix[j][k]]=cs*t1+sn*t2; v[k]=-sn*t1+cs*t2; }
    v[j]=0.0; }
}
// s2.4 augmented QR:  [B_p ; D_p^{1/2}] = Q R,  V = R^T R exactly, kappa(R)=kappa(V)^{1/2}

__global__ void MFPointFactorTau(const Scalar* __restrict__ Cdiag,
    const Scalar* __restrict__ R0f,Scalar tau,int npt,
    Scalar* __restrict__ Rf,int* __restrict__ ok){
  int p=blockIdx.x*blockDim.x+threadIdx.x; if(p>=npt)return;
  Scalar cd[3]={Cdiag[3*p],Cdiag[3*p+1],Cdiag[3*p+2]};
  Scalar tr=cd[0]+cd[1]+cd[2], fl=tau*tr/3.0; if(!(fl>0.0)) fl=1e-32;
  Scalar Rp[6]; for(int i=0;i<6;++i) Rp[i]=R0f[6*p+i];
  for(int i=0;i<3;++i){ Scalar q=tau*cd[i]; if(!(q>1e-3*fl)) q=1e-3*fl;
    Scalar v[3]={0,0,0}; v[i]=sqrt(q); MFGivens(Rp,v); }
  ok[p]=((Rp[0]>0.0)&&(Rp[3]>0.0)&&(Rp[5]>0.0))?1:0;
  for(int i=0;i<6;++i) Rf[6*p+i]=Rp[i];
}

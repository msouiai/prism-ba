__device__ __forceinline__ void MFVinv(const Scalar* Rp,const Scalar* tv,Scalar* u){
  Scalar y0=tv[0]/Rp[0];
  Scalar y1=(tv[1]-Rp[1]*y0)/Rp[3];
  Scalar y2=(tv[2]-Rp[2]*y0-Rp[4]*y1)/Rp[5];
  u[2]=y2/Rp[5]; u[1]=(y1-Rp[4]*u[2])/Rp[3]; u[0]=(y0-Rp[1]*u[1]-Rp[2]*u[2])/Rp[0];
}
template <int CD, class HT>
__global__ void MFPass1(const HT* __restrict__ Gp,const int* __restrict__ scam,
    const int* __restrict__ spt,const Scalar* __restrict__ v,int nobs,Scalar* __restrict__ tacc){
  int k=blockIdx.x*blockDim.x+threadIdx.x; if(k>=nobs)return;
  int p=spt[k]; const Scalar* vc=v+CD*scam[k];
  for(int j=0;j<3;++j){ Scalar q=0;
    for(int i=0;i<CD;++i) q+=Gp[(size_t)(3*i+j)*nobs+k]*vc[i];
    atomicAdd(&tacc[3*p+j],q); }
}

__global__ void MFVinvApply(const Scalar* __restrict__ Rf,const Scalar* __restrict__ tacc,int npt,Scalar* __restrict__ u){
  int p=blockIdx.x*blockDim.x+threadIdx.x; if(p>=npt)return;
  const Scalar* Rp=Rf+6*p;
  if(!(Rp[0]>0.0&&Rp[3]>0.0&&Rp[5]>0.0)){ u[3*p]=u[3*p+1]=u[3*p+2]=0.0; return; }
  Scalar tv[3]={tacc[3*p],tacc[3*p+1],tacc[3*p+2]},uu[3]; MFVinv(Rp,tv,uu);
  u[3*p]=uu[0];u[3*p+1]=uu[1];u[3*p+2]=uu[2];
}

template <int CD, class HT>
__global__ void MFPass2(const HT* __restrict__ Gc,const int* __restrict__ cspt,
    const int* __restrict__ coff,const Scalar* __restrict__ u,const Scalar* __restrict__ Hcc,
    const Scalar* __restrict__ v,int nobs,Scalar* __restrict__ w,const int* __restrict__ slots=nullptr){
  int c=blockIdx.x; int s=coff[c],e=coff[c+1];
  Scalar acc[CD];
  for(int i=0;i<CD;++i) acc[i]=0;
  for(int k=s+threadIdx.x;k<e;k+=blockDim.x){
    int p=cspt[k]; const int gk=slots?slots[k]:k; Scalar up[3]={u[3*p],u[3*p+1],u[3*p+2]};
    for(int i=0;i<CD;++i){ Scalar q=0;
      for(int j=0;j<3;++j) q+=Gc[(size_t)(3*i+j)*nobs+gk]*up[j];
      acc[i]+=q; } }
  __shared__ Scalar sh[CD][256];
  for(int i=0;i<CD;++i) sh[i][threadIdx.x]=acc[i];
  __syncthreads();
  for(int st=128;st>0;st>>=1){ if(threadIdx.x<st) for(int i=0;i<CD;++i) sh[i][threadIdx.x]+=sh[i][threadIdx.x+st]; __syncthreads(); }
  if(threadIdx.x==0) for(int i=0;i<CD;++i){
    Scalar q=0; for(int j=0;j<CD;++j) q+=Hcc[CD*CD*c+CD*i+j]*v[CD*c+j];
    w[CD*c+i]=q-sh[i][0]; }
}

template <int CD, typename HT>
__global__ void MFBlockSchur(const HT* __restrict__ Gp,const int* __restrict__ spt,
    const int* __restrict__ scam,const Scalar* __restrict__ Rf,int nobs,
    Scalar* __restrict__ Bk){
  int k=blockIdx.x*blockDim.x+threadIdx.x; if(k>=nobs)return;
  int p=spt[k],c=scam[k]; const Scalar* Rp=Rf+6*p;
  if(!(Rp[0]>0.0&&Rp[3]>0.0&&Rp[5]>0.0)) return;
  Scalar W[CD*3], U[CD*3];
  for(int i=0;i<CD;++i){
    W[3*i+0]=Gp[(size_t)(3*i+0)*nobs+k];
    W[3*i+1]=Gp[(size_t)(3*i+1)*nobs+k];
    W[3*i+2]=Gp[(size_t)(3*i+2)*nobs+k];
    MFVinv(Rp,&W[3*i],&U[3*i]);
  }
  for(int i=0;i<CD;++i)
    for(int j=0;j<CD;++j)
      atomicAdd(&Bk[(size_t)CD*CD*c+CD*i+j],
                -(W[3*i+0]*U[3*j+0]+W[3*i+1]*U[3*j+1]+W[3*i+2]*U[3*j+2]));
}
// CAMERA-MAJOR Schur block build -- same result as MFBlockSchur but with NO
// atomics.  One warp per camera walks that camera's own observation run via the
// existing CSR (coff/cspt, the MFPass2 pattern), accumulates in registers, and
// reduces down a fixed shuffle tree, so the summation order is identical on
// every launch.  The atomicAdd version is run-to-run nondeterministic (81 float
// adds per observation arriving in arbitrary order); on ladybug-1723 that
// variance reaches 15% at L=5 and 698% at L=1, while the diagonal path is
// bit-identical across repeats -- the suspected cause of that dataset's
// long-standing block-preconditioner failure.
// Only the lower triangle is accumulated (S_c is symmetric and MFBlockChol
// symmetrises anyway), halving both registers and work.
template <int CD, typename HT>
__global__ void MFBlockSchurCM(const HT* __restrict__ Gc,const int* __restrict__ cspt,
    const int* __restrict__ coff,const Scalar* __restrict__ Rf,int nobs,
    Scalar* __restrict__ Bk,const int* __restrict__ slots=nullptr){
  const int c=blockIdx.x; const int s=coff[c],e=coff[c+1];
  constexpr int NT=(CD*(CD+1))/2;
  Scalar acc[NT];
  for(int t=0;t<NT;++t) acc[t]=0.0;
  for(int k=s+threadIdx.x;k<e;k+=warpSize){
    int p=cspt[k]; const int gk=slots?slots[k]:k; const Scalar* Rp=Rf+6*p;
    if(!(Rp[0]>0.0&&Rp[3]>0.0&&Rp[5]>0.0)) continue;
    Scalar W[CD*3],U[CD*3];
    for(int i=0;i<CD;++i){
      W[3*i+0]=Gc[(size_t)(3*i+0)*nobs+gk];
      W[3*i+1]=Gc[(size_t)(3*i+1)*nobs+gk];
      W[3*i+2]=Gc[(size_t)(3*i+2)*nobs+gk];
      MFVinv(Rp,&W[3*i],&U[3*i]);
    }
    int t=0;
    for(int i=0;i<CD;++i) for(int j=0;j<=i;++j,++t)
      acc[t]-=(W[3*i+0]*U[3*j+0]+W[3*i+1]*U[3*j+1]+W[3*i+2]*U[3*j+2]);
  }
  __shared__ Scalar red[NT];
  for(int t=0;t<NT;++t){
    Scalar v=acc[t];
    for(int off=16;off>0;off>>=1) v+=__shfl_down_sync(0xffffffffu,v,off);
    if(threadIdx.x==0) red[t]=v;
  }
  __syncthreads();
  if(threadIdx.x==0){
    int t=0;
    for(int i=0;i<CD;++i) for(int j=0;j<=i;++j,++t){
      Bk[(size_t)CD*CD*c+CD*i+j]+=red[t];
      if(i!=j) Bk[(size_t)CD*CD*c+CD*j+i]+=red[t];
    }
  }
}
template <int CD>
__global__ void MFBlockAddHcc(const Scalar* __restrict__ Hcc,int ncam,Scalar* __restrict__ Bk){
  int c=blockIdx.x*blockDim.x+threadIdx.x; if(c>=ncam)return;
  for(int i=0;i<CD*CD;++i) Bk[(size_t)CD*CD*c+i]+=Hcc[(size_t)CD*CD*c+i];
}
// ---- SHARED-INTRINSICS reduced space -------------------------------------
// The CG works in [6*ncam poses | 3*ncalib calibration] = B^T S B, so the
// per-camera 9x9 blocks cannot be used directly. Split them instead:
//   pose block  (6x6, one per camera)  = top-left 6x6 of the 9x9
//   calib block (3x3, one per GROUP)   = sum of the bottom-right 3x3 over the
//                                        cameras in that group
// This is the exact block-diagonal of B^T S B EXCEPT for cross-camera terms
// c != c' within a group (cameras sharing points). Those are dropped -- a
// block-diagonal preconditioner is an approximation regardless -- so the
// calibration block is a lower bound on the true group curvature.
// Pose-calibration cross terms are likewise off-block and dropped.
template <int CD>
__global__ void MFBlockRedSplit(const Scalar* __restrict__ Bk,
    const int* __restrict__ calib_of_cam,int ncam,
    Scalar* __restrict__ Bp,Scalar* __restrict__ Bg){
  int c=blockIdx.x*blockDim.x+threadIdx.x; if(c>=ncam)return;
  const Scalar* B=Bk+(size_t)CD*CD*c;
  for(int i=0;i<6;++i)
    for(int j=0;j<6;++j) Bp[(size_t)36*c+6*i+j]=B[CD*i+j];
  const int g=calib_of_cam[c];
  for(int i=0;i<3;++i)
    for(int j=0;j<3;++j)
      atomicAdd(&Bg[(size_t)9*g+3*i+j],B[CD*(6+i)+(6+j)]);
}
// Cholesky of each block, in place: lower triangle of Bk becomes L.
// Degrades to diagonal scaling if the block is not positive definite.
// OCA_RI_OPEN helper: Levenberg damping of a per-camera block diagonal
// (B_ii *= 1+lam, with an absolute floor so an all-zero block stays SPD).
template <int CD>
__global__ void MFBlockDampDiag(Scalar* __restrict__ Bk,int ncam,Scalar lam){
  int c=blockIdx.x*blockDim.x+threadIdx.x; if(c>=ncam)return;
  Scalar* B=Bk+(size_t)CD*CD*c;
  for(int i=0;i<CD;++i){
    Scalar d=B[CD*i+i];
    B[CD*i+i]=d*((Scalar)1.0+lam)+lam*(Scalar)1e-12;
  }
}
template <int CD>
__global__ void MFBlockChol(Scalar* __restrict__ Bk,int ncam,Scalar eps,
                            int* __restrict__ nfail=nullptr){
  int c=blockIdx.x*blockDim.x+threadIdx.x; if(c>=ncam)return;
  Scalar* B=Bk+(size_t)CD*CD*c;
  Scalar mx=0.0;
  for(int i=0;i<CD;++i){ Scalar d=fabs(B[CD*i+i]); if(d>mx)mx=d; }
  const Scalar fl=fmax(mx*eps,(Scalar)1e-30);
  for(int i=0;i<CD;++i) if(!(B[CD*i+i]>fl)) B[CD*i+i]=fl;
  bool ok=true;
  Scalar L[CD*CD];
  for(int i=0;i<CD*CD;++i) L[i]=0.0;
  for(int i=0;i<CD&&ok;++i)
    for(int j=0;j<=i;++j){
      Scalar sum=(Scalar)0.5*(B[CD*i+j]+B[CD*j+i]);
      for(int k=0;k<j;++k) sum-=L[CD*i+k]*L[CD*j+k];
      if(i==j){ if(!(sum>0.0)){ ok=false; break; } L[CD*i+j]=sqrt(sum); }
      else      L[CD*i+j]=sum/L[CD*j+j];
    }
  if(!ok){ if(nfail) atomicAdd(nfail,1);
           for(int i=0;i<CD*CD;++i) L[i]=0.0;
           for(int i=0;i<CD;++i) L[CD*i+i]=sqrt(fmax(B[CD*i+i],fl)); }
  for(int i=0;i<CD*CD;++i) B[i]=L[i];
}
// y = L^-1 x  (mode 0)   /   y = L^-T x  (mode 1), per camera
template <int CD>
__global__ void MFBlockSolve(const Scalar* __restrict__ Bk,const Scalar* __restrict__ x,
                             int ncam,int mode,Scalar* __restrict__ y){
  int c=blockIdx.x*blockDim.x+threadIdx.x; if(c>=ncam)return;
  const Scalar* L=Bk+(size_t)CD*CD*c;
  const Scalar* xc=x+CD*c; Scalar* yc=y+CD*c;
  if(mode==0){
    for(int i=0;i<CD;++i){ Scalar s=xc[i];
      for(int k=0;k<i;++k) s-=L[CD*i+k]*yc[k];
      yc[i]=s/L[CD*i+i]; }
  } else {
    for(int i=CD-1;i>=0;--i){ Scalar s=xc[i];
      for(int k=i+1;k<CD;++k) s-=L[CD*k+i]*yc[k];
      yc[i]=s/L[CD*i+i]; }
  }
}

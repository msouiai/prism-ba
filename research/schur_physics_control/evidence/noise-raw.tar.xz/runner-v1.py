#!/usr/bin/env python3
"""Bounded paired initialization stress; no changes to the measured binary."""
import csv
import datetime
import fcntl
import json
import os
import pathlib
import platform
import re
import shutil
import subprocess
import tempfile
import time
import numpy as np
from noisy_scene import Scene, SOURCE, digest

ROOT = pathlib.Path(__file__).resolve().parent
OUT = pathlib.Path(os.environ.get('PRISM_NOISE_OUT', '/tmp/prism-schur-physics-noise'))
TARGET = 27318392.631312046
CAP = 12

def put(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')

def run(binary, cfg, input_path, case, rank, base):
    stem = OUT/f"px{case['requested_sample_median_px']:g}-seed{case['seed']}-r{rank}"
    flags = cfg['flags'] | {'OCA_COARSE_RANK': str(rank), 'OCA_MAX_SECONDS': str(CAP),
                            'OCA_TARGET_COST': str(TARGET)}
    cmd = [str(binary), '--problem', str(input_path), *cfg['cli'], '--csv', str(stem.with_suffix('.csv'))]
    # with_suffix is unsuitable for decimal case names; use explicit suffixes.
    log_path, csv_path, json_path = [pathlib.Path(str(stem)+ext) for ext in ['.log', '.csv', '.json']]
    cmd[-1] = str(csv_path)
    start = time.monotonic()
    print('RUN', stem.name, flush=True)
    with log_path.open('w') as f:
        try:
            rc = subprocess.run(cmd, env=base | flags, stdout=f, stderr=subprocess.STDOUT, timeout=120).returncode
        except subprocess.TimeoutExpired:
            rc = 124
    text = log_path.read_text()
    row = {'case': case, 'rank': rank, 'command': cmd, 'flags': flags, 'returncode': rc,
           'process_seconds': time.monotonic()-start, 'target': TARGET,
           'target_event': False, 'hit_within_budget': False, 'log': log_path.name, 'csv': csv_path.name}
    m = re.search(r'RESULT algo=\S+ iters=(\d+) final_cost=(\S+) solve_seconds=(\S+)', text)
    if m:
        row.update(outers=int(m[1]), final_cost=float(m[2]), native_seconds=float(m[3]))
    m = re.search(r'TARGET reached outer=(\d+) seconds=(\S+) cost=(\S+) threshold=(\S+)', text)
    if m:
        row.update(target_event=True, target_outer=int(m[1]), target_seconds=float(m[2]), target_cost=float(m[3]),
                   hit_within_budget=rc == 0 and float(m[2]) <= CAP and float(m[3]) <= TARGET)
    m = re.search(r'MFCG: accepts=(\d+) rejects=(\d+) total_matvecs=(\d+)', text)
    if m:
        row.update(accepts=int(m[1]), rejects=int(m[2]), matvecs=int(m[3]))
    preparations = [dict(x.split('=', 1) for x in line.split()[1:] if '=' in x)
                    for line in text.splitlines() if line.startswith('COARSE_PREP ')]
    row['coarse_active'] = sum(int(x['active']) for x in preparations)
    row['max_prior_depth'] = max((int(x['prior_depth']) for x in preparations), default=None)
    row['coarse_preparations'] = preparations
    row['stop_messages'] = [line for line in text.splitlines() if 'BUDGET' in line or 'converged (' in line]
    if csv_path.exists():
        with csv_path.open() as f:
            trace = list(csv.DictReader(line for line in f if not line.startswith('#')))
        if trace:
            row['initial_native_cost'] = float(trace[0]['cost'])
            row['initial_cpu_relative_error'] = abs(row['initial_native_cost']/case['initial_cost']-1)
            # A sensitive initialization is not silently accepted as loader parity.
            row['initial_cost_verified'] = row['initial_cpu_relative_error'] < 1e-6
    put(json_path, row)
    print(json.dumps({k: row.get(k) for k in ['rank', 'hit_within_budget', 'target_seconds', 'final_cost',
                                               'native_seconds', 'outers', 'rejects', 'coarse_active', 'max_prior_depth',
                                               'initial_cost_verified']}), flush=True)
    return row

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    if (OUT/'manifest.json').exists():
        raise SystemExit('Output cohort already exists; choose a fresh PRISM_NOISE_OUT.')
    binary = ROOT/'build/prism-coarse'
    build = json.loads((ROOT/'build/solver-manifest.json').read_text())
    assert digest(binary) == build['binary_sha256']
    cfg = json.loads((ROOT.parent/'eta2_champion/champion.json').read_text())
    assert digest(SOURCE) == '76ef34416fdca524b1ec6755b62ab33cba15c8b5b830b5ff38369c8cd609d736'
    shutil.copy2(ROOT/'NOISE_PROTOCOL.md', OUT/'PROTOCOL.md')
    put(OUT/'manifest.json', {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'python': platform.python_version(), 'numpy': np.__version__, 'binary_sha256': digest(binary),
        'generator_sha256': digest(ROOT/'noisy_scene.py'), 'runner_sha256': digest(__file__),
        'protocol_sha256': digest(ROOT/'NOISE_PROTOCOL.md'), 'input_sha256': digest(SOURCE),
        'flags': cfg['flags'], 'cli': cfg['cli'], 'seeds': [17, 29, 43], 'levels_px': [.25, 1.],
        'target': TARGET, 'native_cap': CAP, 'timing_repeats_per_input': 1})
    print('REGISTERED; loading scene', flush=True)
    scene = Scene()
    assert scene.obs_sha == '89212219a95d8748c068769d8642dbd802c6f59e64833aaece44078a81a81e49'
    print('LOADED', scene.dims, flush=True)
    base = {k: v for k, v in os.environ.items() if not k.startswith(('OCA_', 'CASPAR_', 'COLMAP_MFREE', 'MF_DEBUG'))}
    rows, cases = [], []
    with tempfile.TemporaryDirectory(prefix='prism-noise-', dir='/dev/shm') as tmp:
        input_path = pathlib.Path(tmp)/'input.txt'
        with open('/tmp/prism_gpu.lock', 'w') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            for si, seed in enumerate([17, 29, 43]):
                for li, pixels in enumerate([.25, 1.]):
                    c, x, case = scene.perturb(seed, pixels)
                    case.update(scene.inspect(c, x))
                    print('GEOMETRY', json.dumps(case), flush=True)
                    case['input_sha256'] = scene.write(input_path, c, x)
                    del c, x
                    case['readback_verified'] = True
                    cases.append(case)
                    put(OUT/'cases.json', cases)
                    for rank in ([0, 16] if (si+li)%2 == 0 else [16, 0]):
                        rows.append(run(binary, cfg, input_path, case, rank, base))
                        put(OUT/'runs.json', rows)
    put(OUT/'completion.json', {'complete': len(rows) == 12, 'runs': len(rows),
        'all_successful': all(r['returncode'] == 0 and r.get('initial_cost_verified') for r in rows),
        'native_seconds': sum(r.get('native_seconds', 0) for r in rows)})
    print('DONE', flush=True)

if __name__ == '__main__':
    main()

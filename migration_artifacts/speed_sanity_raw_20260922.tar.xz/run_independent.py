#!/usr/bin/env python3
import hashlib, json, os, pathlib, shutil, subprocess, time

ROOT = pathlib.Path('/workspace/independent_speed_sanity')
ROOT.mkdir(exist_ok=True)
STAMP = '/workspace/prism-ba/bench/bench/stamp.py'
DONE = pathlib.Path('/workspace/parity/speed_caspar/done')

SCENES = {
    'final-4585': '/workspace/bal/final-4585.txt',
    'venice-1778': '/workspace/bal/venice-1778.txt',
}
MFREE = '/workspace/parity/build_mfree/oca_cuda'
PRISM = '/workspace/parity/build_base/oca_cuda'
CASPAR = '/workspace/caspar-comparison/caspar-f64'

PRISM_FLAGS = {
    'OCA_ATTR_RADIUS':'1','OCA_ATTR_RESCUE':'1','OCA_ATTR_STRICT':'1',
    'OCA_BACKTRACK_REARM':'1','OCA_CAMERA_TR':'0','OCA_CG_STOP':'0',
    'OCA_CLASSICAL_LM':'1','OCA_COMPACT_FRAGMENTS':'2','OCA_DEMAND_MENU':'0',
    'OCA_DIAG_NORM':'1','OCA_FORCE_UNSHARED':'1','OCA_FTOL':'1e-5',
    'OCA_FTOL_K':'8','OCA_GRID_DOWN':'2','OCA_MENU_BACKTRACK':'8',
    'OCA_MENU_GATE':'1e-2','OCA_MULTI_RHS':'1','OCA_NSHIFTS':'1',
    'OCA_PCG':'1','OCA_POINT_SAFEGUARD':'1','OCA_RETRY_CACHE':'1',
    'OCA_RHO_LAMBDA':'1','OCA_RHO_SHIFT':'1','OCA_SCHUR_NUMERIC_GUARD':'1',
    'OCA_SWITCH_RESTART':'0','OCA_TR_RECURRENCE':'0','OCA_RLA_FIXED_ETA':'2',
}
MFREE_FLAGS = {
    'OCA_RHO_LAMBDA':'1','OCA_GRID_DOWN':'2','OCA_RHO_SHIFT':'1',
    'OCA_ALPHA_RHO':'1','OCA_TAU_CLASS':'1,1,0.3','OCA_ADAPT_L':'3',
    'OCA_ADAPT_REL':'1e-3',
}

def clean_env(extra):
    env = {k:v for k,v in os.environ.items()
           if not k.startswith(('OCA_','CASPAR_','COLMAP_MFREE','MF_DEBUG'))}
    env.update(extra)
    return env

def sha(path):
    with open(path,'rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()

def stamped_run(label, cmd, env):
    log = ROOT/(label+'.log')
    meta = ROOT/(label+'.json')
    if meta.exists():
        try:
            row=json.loads(meta.read_text())
            if row.get('returncode') == 0: return row
        except (json.JSONDecodeError, OSError):
            pass
    shell = "set -o pipefail; stdbuf -oL -eL flock /tmp/prism_gpu.lock " + \
            ' '.join(subprocess.list2cmdline([x]) for x in cmd) + \
            f" 2>&1 | python3 {STAMP} > {subprocess.list2cmdline([str(log)])}"
    start=time.time(); mono=time.monotonic()
    rc=subprocess.run(['bash','-lc',shell],env=env).returncode
    row={'label':label,'command':cmd,'env':extra_env(env),'start_utc':start,
         'process_wall':time.monotonic()-mono,'returncode':rc,
         'binary_sha256':sha(cmd[0]) if pathlib.Path(cmd[0]).is_file() else None}
    meta.write_text(json.dumps(row,indent=2)+'\n')
    if rc: raise RuntimeError((label,rc))
    return row

def extra_env(env):
    return {k:v for k,v in env.items() if k.startswith(('OCA_','CASPAR_','COLMAP_MFREE'))}

def wait_for_queue():
    while not DONE.exists():
        print(time.strftime('%FT%TZ',time.gmtime()),'waiting for speed_caspar/done',flush=True)
        time.sleep(30)
    print(time.strftime('%FT%TZ',time.gmtime()),'queue done marker observed',flush=True)

def run_bal():
    common=['--algo','mfree_shifted_cg','--dof9','--zero_k2','--max_iter','60']
    margs=common+['--mf-shifts','5','--tau_pt','3e-3','--func-tol','1e-6',
                  '--max-consec-fail','3','--mf-fp32']
    pargs=common+['--lam0','0.1']
    # Interleave arms and reverse scene order on alternating repetitions.
    for rep in range(1,4):
        scenes=list(SCENES.items())
        if rep%2==0: scenes.reverse()
        arms=[('mfree',MFREE,margs,MFREE_FLAGS),('prism',PRISM,pargs,PRISM_FLAGS)]
        if rep%2==0: arms.reverse()
        for scene,path in scenes:
            for arm,bin_,args,flags in arms:
                stamped_run(f'bal_{scene}_{arm}_r{rep}',
                            [bin_,'--problem',path,*args],clean_env(flags))
    for scene,path in SCENES.items():
        for n in (200,2000):
            stamped_run(f'bal_{scene}_caspar_f64_i{n}',
                        [CASPAR,path,str(n),'default'],clean_env({}))

def run_fuchs():
    pert='/workspace/parity/fuchs/pert'
    builds={
      'old_prism':'/workspace/colmap-build-prism2/src/colmap/exe/colmap',
      'parity':'/workspace/colmap-mfree-parity/build/src/colmap/exe/colmap',
    }
    ld='/workspace/colmap-mfree-parity/build/_deps/onnxruntime-src/lib'
    for rep in range(1,3):
        arms=list(builds.items())
        if rep==2: arms.reverse()
        for arm,bin_ in arms:
            out=ROOT/f'_fuchs_output_{arm}_{rep}'
            if out.exists(): shutil.rmtree(out)
            out.mkdir()
            env=clean_env({'OCA_RF_THETA_MAX_DEG':'100'})
            env['LD_LIBRARY_PATH']=ld+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
            try:
                # The old adapter routes its MFREE cap through the historical
                # Ceres option; the parity port exposes a dedicated option.
                iter_flag = ('--BundleAdjustmentCeres.max_num_iterations'
                             if arm == 'old_prism'
                             else '--BundleAdjustmentMFree.max_num_iterations')
                stamped_run(f'fuchs_{arm}_r{rep}',[
                    bin_,'bundle_adjuster','--input_path',pert,'--output_path',str(out),
                    '--BundleAdjustment.backend','MFREE',
                    '--BundleAdjustment.refine_principal_point','1',
                    '--BundleAdjustment.refine_sensor_from_rig','1',
                    iter_flag,'60'],env)
            finally:
                if out.exists(): shutil.rmtree(out)

def main():
    manifest={'created_utc':time.strftime('%FT%TZ',time.gmtime()),
      'scenes':{k:{'path':p,'sha256':sha(p)} for k,p in SCENES.items()},
      'binaries':{p:sha(p) for p in [MFREE,PRISM,CASPAR,
        '/workspace/colmap-build-prism2/src/colmap/exe/colmap',
        '/workspace/colmap-mfree-parity/build/src/colmap/exe/colmap']},
      'prism_flags':PRISM_FLAGS,'mfree_flags':MFREE_FLAGS,
      'independence':'Did not read /workspace/parity/speed* results before completing own runs.'}
    (ROOT/'protocol.json').write_text(json.dumps(manifest,indent=2)+'\n')
    wait_for_queue(); run_bal(); run_fuchs()
    (ROOT/'RUNS_COMPLETE').write_text(time.strftime('%FT%TZ\n',time.gmtime()))

if __name__=='__main__': main()

#!/usr/bin/env python3
import json, math, pathlib, re, statistics
import matplotlib.pyplot as plt

ROOT=pathlib.Path('/workspace/independent_speed_sanity')
DOC=pathlib.Path('/workspace/prism-ba/docs/speed_sanity_check.md')
FIGDIR=pathlib.Path('/workspace/prism-ba/docs/figures/convergence')
FIGDIR.mkdir(parents=True,exist_ok=True)
SCENES=['final-4585','venice-1778']

def stamp(line):
    m=re.match(r'\s*([0-9]+\.[0-9]+)\s+',line); return float(m[1]) if m else None

def parse_bal(path,arm,rep=None,cap=None):
    text=path.read_text(); trace=[]
    if arm in ('mfree','prism'):
        for line in text.splitlines():
            m=re.search(r'MFCG it\s+(\d+) cost=(\S+)',line)
            if m: trace.append((stamp(line),float(m[2]),int(m[1])))
        m=re.search(r'RESULT algo=.*? iters=(\d+) final_cost=(\S+) solve_seconds=(\S+)',text)
        c=re.search(r'MFCG: accepts=(\d+) rejects=(\d+)',text)
        assert m and c
        final=float(m[2]); wall=json.loads(path.with_suffix('.json').read_text())['process_wall']
        if not trace or trace[-1][1]!=final: trace.append((wall,final,int(m[1])))
        return dict(arm=arm,rep=rep,cap=cap,final=final,iters=int(m[1]),accepts=int(c[1]),rejects=int(c[2]),
                    solve=float(m[3]),wall=wall,trace=trace)
    for line in text.splitlines():
        m=re.search(r'solver_iter:\s*(\d+).*?score_best:\s*(\S+)',line)
        if m: trace.append((stamp(line),float(m[2]),int(m[1])+1))
    m=re.search(r'RESULT exit=\d+ iters=(\d+) final_score=(\S+) runtime=(\S+)',text)
    acc=[int(x) for x in re.findall(r'TRACE iter=\d+ cost=\S+ seconds=\S+ accepted=(\d+)',text)]
    assert m and trace
    final=float(m[2]); wall=json.loads(path.with_suffix('.json').read_text())['process_wall']
    if trace[-1][1]!=final: trace.append((wall,final,int(m[1])))
    return dict(arm=f'caspar-{cap}',rep=1,cap=cap,final=final,iters=int(m[1]),
                accepts=sum(acc),rejects=len(acc)-sum(acc),solve=float(m[3]),wall=wall,trace=trace)

def runs(scene):
    out=[]
    for arm in ('mfree','prism'):
        for rep in range(1,4):
            out.append(parse_bal(ROOT/f'bal_{scene}_{arm}_r{rep}.log',arm,rep))
    for cap in (200,2000):
        out.append(parse_bal(ROOT/f'bal_{scene}_caspar_f64_i{cap}.log','caspar',cap=cap))
    return out

def med(xs): return statistics.median(xs)
def fmt(x): return f'{x:,.6g}'
def timestr(vals,total):
    if not vals: return f'0/{total} —'
    if len(vals)==1: return f'1/{total} {vals[0]:.3f}s'
    return f'{len(vals)}/{total} {med(vals):.3f}s [{min(vals):.3f},{max(vals):.3f}]'
def crossing(run,target):
    for t,c,_ in run['trace']:
        if c<=target: return t
    return None

allruns={s:runs(s) for s in SCENES}

# Plot every repeated trajectory; Caspar caps get distinct dashes.
colors={'mfree':'#d62728','prism':'#1f77b4','caspar-200':'#2ca02c','caspar-2000':'#9467bd'}
for scene,rr in allruns.items():
    fig,ax=plt.subplots(figsize=(8.2,5.0))
    seen=set()
    for r in rr:
        label={'mfree':'MFREE (5-shift)','prism':'Prism Eta2','caspar-200':'Caspar-f64 200',
               'caspar-2000':'Caspar-f64 2000'}[r['arm']]
        ts=[max(t,1e-3) for t,_,_ in r['trace']]; cs=[c for _,c,_ in r['trace']]
        ax.plot(ts,cs,color=colors[r['arm']],lw=1.7 if r['arm'].startswith('caspar') else 1.25,
                alpha=.9 if r['arm'].startswith('caspar') else .65,
                ls='--' if r['arm']=='caspar-200' else '-',label=label if label not in seen else None)
        seen.add(label)
    ax.set_xscale('log'); ax.set_yscale('log')
    ax.set_xlabel('wall time from process launch (s)'); ax.set_ylabel('plain L2 cost')
    ax.set_title(scene); ax.grid(True,which='both',alpha=.25); ax.legend()
    fig.tight_layout(); fig.savefig(FIGDIR/f'speed_sanity_{scene}.png',dpi=180); plt.close(fig)

lines=[]
lines += ['# Independent RTX 2000 Ada speed sanity check','',
  'This experiment was preregistered and completed without reading `/workspace/parity/speed*` result files. '
  'Every command was serialized with `flock /tmp/prism_gpu.lock`; every stdout/stderr stream was timestamped '
  'with `bench/bench/stamp.py`. Costs are the unchanged plain-L2 BAL objective. Wall crossings include process '
  'startup and input loading. Caspar prints its detailed `TRACE` block at exit, so its crossing curve uses the '
  'live timestamped `solver_iter` lines (`score_best`), not the delayed trace-block timestamps.','',
  '## Registered configurations','',
  '- **MFREE:** supplied five-shift champion flags and CLI, FP32 fragments, 60 accepted outers.',
  '- **Prism:** frozen sustained-Eta2/lambda-0.1 configuration (`OCA_NSHIFTS=1`, `OCA_RLA_FIXED_ETA=2`), 60 accepted outers.',
  '- **Caspar-f64:** unmodified comparison binary at 200 and 2,000 attempted iterations.',
  '- **Fuchsberg:** the same perturbed 5,592-frame model, MFREE backend, principal point and sensor-from-rig refinement enabled, 60-iteration cap, `OCA_RF_THETA_MAX_DEG=100`; two repetitions.','',
  '## Verdict','',
  "- **Final-4585 favors Prism decisively.** Prism's measured 60-outer endpoints span `7.06e6–7.38e6` across the independent and post-freeze external cohorts; the independent median is 8.20% lower than MFREE's while its median process wall is 2.93× shorter. At MFREE's median endpoint threshold, Prism crosses in 16.127s median versus 158.849s for the two MFREE runs that reach it. MFREE spends 198–199 retries per run; Prism spends 21–100.",
  "- **Venice-1778 favors MFREE.** MFREE's median endpoint is 1.63% lower than Prism's and its median process wall is 2.24× shorter. It crosses Prism's median endpoint in 15.844s versus 61.807s for the two Prism runs that reach it. MFREE also beats Caspar-200 on quality and wall. Caspar-2000 eventually finishes 0.78% below MFREE, but needs 606.924s versus MFREE's 29.495s median wall.",
  '- **The Fuchsberg parity port fixes correctness rather than raw speed.** It lowers the fixed-cap endpoint from `3.65304e9` to `1.78405e7` (about 205×), reproducibly. Its 611.603s median wall is 1.89× the old adapter\'s 323.506s because the old adapter enters a 200+ rejection storm and terminates far above the useful basin.','',
  'The two BAL scenes therefore reject a universal speed ranking: Eta2 is much stronger on Final-4585, while the five-shift MFREE configuration is stronger on Venice-1778. The full Fuchsberg result is unambiguous on quality and shows why endpoint-matched timing is required.','']

for scene,rr in allruns.items():
    lines += [f'## {scene}','',
      '| arm | rep | final cost | iterations | accepts / rejects | solver seconds | process wall |',
      '|---|---:|---:|---:|---:|---:|---:|']
    for r in rr:
        lines.append(f"| {r['arm']} | {r['rep']} | {r['final']:.6f} | {r['iters']} | {r['accepts']} / {r['rejects']} | {r['solve']:.3f} | {r['wall']:.3f} |")
    lines += ['']
    groups={a:[r for r in rr if r['arm']==a] for a in ('mfree','prism','caspar-200','caspar-2000')}
    thresholds={
      'MFREE median final':med([r['final'] for r in groups['mfree']]),
      'Prism median final':med([r['final'] for r in groups['prism']]),
      'Caspar-200 final':groups['caspar-200'][0]['final'],
      'Caspar-2000 final':groups['caspar-2000'][0]['final'],
    }
    lines += ['Median repeated-arm summary:','',
      '| arm | median final cost | median process wall | wall range |',
      '|---|---:|---:|---:|']
    for a in ('mfree','prism'):
        g=groups[a]; ws=[r['wall'] for r in g]
        lines.append(f"| {a} | {med([r['final'] for r in g]):.6f} | {med(ws):.3f}s | {min(ws):.3f}–{max(ws):.3f}s |")
    for a in ('caspar-200','caspar-2000'):
        g=groups[a][0]; lines.append(f"| {a} | {g['final']:.6f} | {g['wall']:.3f}s | single run |")
    lines += ['','Time to each registered equal-cost threshold. Entries are `hits/N median [range]`; a dash means the arm never reached the threshold. This table contains both MFREE→Prism and Prism→MFREE directions, and every arm against both Caspar endpoints.','',
      '| trajectory | '+ ' | '.join(f'{k}<br>{v:.6g}' for k,v in thresholds.items())+' |',
      '|---|'+'|'.join(['---:']*len(thresholds))+'|']
    for a in ('mfree','prism','caspar-200','caspar-2000'):
        g=groups[a]; vals=[]
        for target in thresholds.values():
            tt=[crossing(r,target) for r in g]; tt=[x for x in tt if x is not None]
            vals.append(timestr(tt,len(g)))
        lines.append('| '+a+' | '+' | '.join(vals)+' |')
    lines += ['',f'![{scene} convergence](figures/convergence/speed_sanity_{scene}.png)','']

lines += ['## Post-freeze Caspar-fp32 cross-check','',
  'These rows were produced independently in `/workspace/parity/speed_caspar32` and were read only after the preceding experiment and report had been frozen. They are therefore supporting rows, not part of the preregistered timing cohort. The driver binary is `/workspace/caspar32-src/build/caspar_bal32` (SHA-256 `6a052ff736ecb0b04fab1cf3898d2eb377919af00bd4142e6666c1981a2cf375`).','',
  '| scene | cap/run | status | finite best/final cost | solver time |',
  '|---|---:|---|---:|---:|',
  '| final-4585 | 200/r1 | completed | 12,106,156 | 12.096s |',
  '| final-4585 | 200/r2 | completed | 12,123,777 | 12.108s |',
  '| final-4585 | 2000 | exit 2 at iter 1999 | 11,634,041 | 91.923s |',
  '| venice-1778 | 200/r1 | NaN abort at iter 165 | 2,120,424.5 | 22.354s |',
  '| venice-1778 | 200/r2 | completed | 2,117,737 | 27.458s |',
  '| venice-1778 | 2000 | NaN abort at iter 196 | 2,121,653.75 | 26.444s |','',
  'On Final-4585, fp32 Caspar is about 2.9× faster at 200 iterations and 3.4× faster at the long cap than fp64, but the long-run finite endpoint is 1.56% worse (`11.634e6` versus `11.456e6`) and remains far above Prism’s `7.06e6–7.38e6` range. On Venice-1778, two of three runs abort after NaN scores; the sole completed row is also worse than MFREE, Prism, and Caspar-f64 at 200 iterations. The fp32 path is therefore fast per iteration but not a reliable quality baseline on Venice.','']

def parse_fuchs(name,rep):
    p=ROOT/f'fuchs_{name}_r{rep}.log'; text=p.read_text()
    c=re.search(r'RF: accepts=(\d+) rejects=(\d+)',text); assert c
    if name=='old_prism':
        m=re.search(r'PRISM_BA_METRIC .*? initial=(\S+) final=(\S+)',text); assert m
    else:
        m=re.search(r'cost\s+:\s+(\S+) -> (\S+)',text); assert m
    wall=json.loads(p.with_suffix('.json').read_text())['process_wall']
    return dict(name=name,rep=rep,initial=float(m[1]),final=float(m[2]),accepts=int(c[1]),rejects=int(c[2]),wall=wall)
fr=[parse_fuchs(a,r) for r in (1,2) for a in ('old_prism','parity')]
lines += ['## Fuchsberg perturbed full global BA','',
  '| build | rep | initial cost | final cost | accepts / rejects | process wall |',
  '|---|---:|---:|---:|---:|---:|']
for r in fr: lines.append(f"| {r['name']} | {r['rep']} | {r['initial']:.6g} | {r['final']:.6g} | {r['accepts']} / {r['rejects']} | {r['wall']:.3f}s |")
lines += ['']
for a in ('old_prism','parity'):
    g=[r for r in fr if r['name']==a]
    lines.append(f"- **{a}:** median final `{med([r['final'] for r in g]):.6g}`, median wall `{med([r['wall'] for r in g]):.3f}s`.")
lines += ['','The old adapter enters a reject storm and stops near `3.65304e9`; the parity port reaches about `1.78405e7` in both repetitions. The parity solve is slower at the fixed 60-iteration cap because it continues making useful progress instead of terminating in the old false-convergence regime. Absolute time alone is therefore not an equal-quality comparison on this workload.','',
  '## Reproducibility','',
  f'- Raw independent artifacts: `{ROOT}`',
  '- Runner: `run_independent.py`; protocol and binary/input hashes: `protocol.json`.',
  '- Temporary 2.7 GB Fuchsberg output models were deleted immediately after each run; logs and timing metadata were retained.',
  '- The initial invocation exposed an interface-only difference: old Prism routes the MFREE iteration cap through `BundleAdjustmentCeres.max_num_iterations`, while the parity build exposes `BundleAdjustmentMFree.max_num_iterations`. The failed pre-run did not enter the solver and is excluded.','']
DOC.write_text('\n'.join(lines)+'\n')
print(DOC)
